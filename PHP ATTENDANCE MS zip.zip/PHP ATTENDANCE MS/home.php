<div class="page-title">Simple Attendance Management System</div>
<hr>